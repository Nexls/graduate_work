import inspect
import sys
from abc import ABC, abstractmethod
from typing import Optional

import intents
from request import Request
from state import STATE_RESPONSE_KEY
from response_helpers import button

class Scene(ABC):

    @classmethod
    def id(cls):
        return cls.__name__

    # генерация ответа сцены
    @abstractmethod
    def reply(self, request):
        raise NotImplementedError()

    # проверка перехода к новой сцене
    def move(self, request: Request):
        next_scene = self.handle_local_intents(request)
        if next_scene is None:
            next_scene = self.handle_global_intents(request)
        return next_scene

    @abstractmethod
    def handle_global_intents(self, request: Request):
        raise NotImplementedError()

    @abstractmethod
    def handle_local_intents(self, request: Request) -> Optional[str]:
        raise NotImplementedError()

    def fallback(self, request: Request):
        return self.make_response('Нихрена непонятно. Спроси нормально.')

    def make_response(self, text, tts=None, card=None, state=None, buttons=None, directives=None):
        response = {
            'text': text,
            'tts': tts if tts is not None else text,
        }
        if card is not None:
            response['card'] = card
        if buttons is not None:
            response['buttons'] = buttons
        if directives is not None:
            response['directives'] = directives

        webhook_response = {
            'response': response,
            'version': '1.0',
            STATE_RESPONSE_KEY: {
                'scene': self.id(),
            },
        }
        if state is not None:
            webhook_response[STATE_RESPONSE_KEY].update(state)
        return webhook_response


class SearchScene(Scene):

    def handle_global_intents(self, request):
        if intents.RESTART in request.intents:
            return Welcome()
        # тут сделать возвращение через функцию и request чтобы по умному понимал какой топ нужен
        elif intents.TOP_FILMS in request.intents:
            return TopFilms()


class Welcome(SearchScene):
    def reply(self, request: Request):
        text = 'Привет! Я - твой проводник в мир кино. Спроси меня о чем-нибудь!'
        return self.make_response(text, buttons=[
            button('Топ фильмов', hide=True)
        ])

    def handle_local_intents(self, request: Request):
        text = 'Это локальный интент'
        return self.make_response(text)


class TopFilms(SearchScene):
    def reply(self, request):
        text = 'Ты на сцене топ фильмов'
        return self.make_response(text)

    def handle_local_intents(self, request: Request):
        pass


def _list_scenes():
    current_module = sys.modules[__name__]
    scenes = []
    for name, obj in inspect.getmembers(current_module):
        if inspect.isclass(obj) and issubclass(obj, Scene):
            scenes.append(obj)
    return scenes


SCENES = {
    scene.id(): scene for scene in _list_scenes()
}
DEFAULT_SCENE = Welcome
