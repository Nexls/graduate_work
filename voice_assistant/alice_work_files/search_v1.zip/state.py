STATE_REQUEST_KEY = 'session'
STATE_RESPONSE_KEY = 'session_state'
